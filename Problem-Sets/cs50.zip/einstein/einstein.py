mass = int(input("m: "))
energy = mass * pow(300000000,2)
print(f"{energy}")
