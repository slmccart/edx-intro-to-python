input = input("What would you like to input? ").lower()
print(input)
