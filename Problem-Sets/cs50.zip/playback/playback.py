prompt = input("What would you like to say slowly? ").replace(" ", "...")
print(prompt)
