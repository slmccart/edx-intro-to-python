import emoji

prompt = input("Input: ")

print("Output:", emoji.emojize(prompt, language="alias"))
